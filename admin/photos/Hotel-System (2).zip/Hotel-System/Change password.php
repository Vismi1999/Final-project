
<?php
  $conn = mysqli_connect('localhost','root','','hotelsystem');

  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error."<br>");
 }
 else{
   //echo  "Success";
}
//  $conn=new connect1 ();
 $cp=$_POST['cp'];
 $np=$_POST['np'];
$cnp=$_POST['cnp'];
 if($np==$cnp)
 {
     $cust_pass= md5($np);
 $sql="update cust_login set password='$cust_pass' where password='$cp'";
 $conn->insertQuery($sql);
 $result=mysqli_query($conn,$sql);
if($result){
     header('location:Change pass.php');
    }else{
     die(mysqli_error($conn));
   } 
  

echo"<script>alert('Your Password Changed Successfully');window.location='index.php';</script>";
}
 else
 {
     echo"<script>alert('Password Doesnot matched');window.location='change pass.php';</script>";
}
?>