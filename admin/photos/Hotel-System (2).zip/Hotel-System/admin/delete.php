<?php
  include 'admin_connect.php';
if(isset($_GET["id"]))
 {

    $addroom=$_GET['id'];
    $select="DELETE FROM tbl_addrooms where addroom_id='$addroom'";
    $result=mysqli_query($conn,$select);
    // echo '<script type="text/javascript">alert("room deleted successfully.")</script>';
    echo "<script type=>alert('room deleted successfully.');</script>";
    header('location: view addroom.php');
    
   
}
?>