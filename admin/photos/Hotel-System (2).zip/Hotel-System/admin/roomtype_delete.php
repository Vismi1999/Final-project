<?php
  include 'admin_connect.php';
if(isset($_GET["id"]))
 {

    $addroom=$_GET['id'];
    $select="DELETE FROM tbl_roomtype where roomtype_id='$roomtype'";
    $result=mysqli_query($conn,$select);
    // echo '<script type="text/javascript">alert("room deleted successfully.")</script>';
    echo "<script type=>alert('room deleted successfully.');</script>";
    header('location: view roomtype.php');
    
   
}
?>