//    echo "<tr>";
                    
                        
                    //      echo"<td>"; echo $rows['addroom_id']; echo"</td>";
                    //      echo"<td>";echo $rows['room_type'] ; echo"</td>";
                    //      echo"<td>"; echo $rows['room_block']; echo"</td>";
                    //      echo"<td>";echo $rows['room_number']; echo"</td>";
                    //      echo"<td>";echo $rows['choose_room']; echo"</td>";
                    //      echo"<td>"; echo $rows['multipleData']; echo"</td>";
                    //      echo"<td>"; echo $rows['price']; echo"</td>";
                    //      echo"<td>"; ?> <a href="edit.php?id=<?php echo $row["addroom_id"];?>"><button type="button" class="btn btn-success">EDIT</button></a><?php echo"</td>";
                    //      echo"<td>"; ?> <a href="delete.php?id=<?php echo $row["addroom_id"];?>"><button type="button" class="btn btn-danger">DELETE</button></a><?php echo"</td>";
                    //      echo "</tr>";