<!DOCTYPE html
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form validation </title>
  <link rel="stylesheet" href="changepass.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
<form class="pt-3" action="Change password" method="post">
  <div class="wrapper">
  
    <header>Change Pasword</header>
    <form action="login1.php" method="POST">
      <div class="field email">
        <div class="input-area">
          <input type="email" name="cp" placeholder="Old Paasword" required>
          
          <i class="error error-icon fas fa-exclamation-circle"></i>
        </div>
        <div class="error error-txt">Email can't be blank</div>
      </div>
      <div class="field password">
        <div class="input-area">
          <input type="password" name="np" placeholder="Current Password" required>
        
          <i class="error error-icon fas fa-exclamation-circle"></i>
        </div><br>
        <div class="field password">
          <div class="input-area">
            <input type="password" name="cnp" placeholder="Conform Password" required>
           
            <i class="error error-icon fas fa-exclamation-circle"></i>
          
      <br>
      
       <div class="pass-txt"></a></div>
      <input type="submit" name="submit" value="Change"><br><br><br>
    
    
   
  </form> 
  <script src="script.js"></script>

  <!-- <script src="script.js"></script> -->
</body>
</html>
